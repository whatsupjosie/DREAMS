# PubCast Core Manifest

This build is the system-only base snapshot.

Included core:
- main.py boot chain
- config/env loading
- health/readiness/doctor routes
- hub, rooms, bots, inference facade, camera engine, recording, governance, security
- static UI shell and required assets directories
- persistence and foundational schemas/models

Removed from this core snapshot:
- EVO subsystem
- BYOK subsystem
- performance profiles
- choreography controller
- lighting subsystem
- vault subsystem
- ethereal avatars
- Jeremy Cricket / thinking-context extras
- avatar authoring / skeleton extras
- docs, reference images, Rust camera sources, tooling extras

Design rule: optional imports may be absent; the app must still boot and report truthfully.
